'use client';

import React, { useEffect } from 'react';
import Breadcrumbs from './Breadcrumbs';
import SchemaTags from './SchemaTags';
import CommonSections from './CommonSections';

interface LocationPageProps {
  city: string; // This is the Hebrew name passed from [slug]/page.tsx
}

interface CityData {
  title: string;
  desc: string;
  soilType: string;
  buildingStyle: string;
  article: string;
  points: string[];
  commonDefects: { title: string; desc: string }[];
  image: string;
  localStats: { label: string; value: string }[];
}

const cityContent: Record<string, CityData> = {
  'תל אביב': {
    title: 'בדק בית בתל אביב | איתור ליקויי בנייה ע"י מהנדס מומחה',
    desc: 'זקוקים לבדק בית בתל אביב? אריקס ביקורת מבנים מספקת ביקורת מבנים הנדסית למגדלי יוקרה, מבני לשימור ודירות חדשות. איתור ליקויי בנייה, רטיבות ובעיות איטום ע"י מהנדס מומחה.',
    soilType: 'כורכר וחול ים (דורש הגנות איטום ייחודיות וניקוז מהיר)',
    buildingStyle: 'מגדלי מגורים (High-Rise), מבני לשימור ותמ"א 38/2',
    article: `ביצוע **בדק בית בתל אביב** מחייב הבנה עמוקה של "סביבה ימית" (Marine Environment). הקרבה לים התיכון גורמת לריכוז מלחים גבוה באוויר, מה שמאיץ קורוזיה בברזל הזיון ובמערכות האלומיניום. במגדלים החדשים (כמו בשרונה או פארק בבלי), אנו שמים דגש על מערכות דיחוס עשן, לחצי מים בקומות גבוהות ואיטום קירות מסך. בבניינים הישנים של מרכז העיר, הבעיה הנפוצה היא רטיבות קפילארית הנובעת ממי תהום גבוהים החודרים דרך יסודות המבנה שאינם מבודדים היטב. 

מחפשים **בדק בית בתל אביב מחיר** הוגן? אנו מציעים מחירון שקוף ללא "תוספת מרכז", כך שתוכלו לקבל ביקורת מבנים הנדסית ברמה הגבוהה ביותר במחיר תחרותי. אריקס ביקורת מבנים מחויבת למקצועיות ללא פשרות, תוך שימוש בציוד טכנולוגי מתקדם לאיתור ליקויי בנייה סמויים שאינם נראים לעין בלתי מזוינת.`,
    points: ['בדיקת קורוזיה בברזל זיון במבנים ותיקים', 'אבחון איטום מרתפים מול מי תהום גבוהים', 'בדיקת קירות מסך ואלומיניום במגדלים', 'ביקורת מערכות משותפות (מעליות, גנרטורים)'],
    commonDefects: [
      { title: 'חדירת מים במרתפים', desc: 'כשל באיטום "קירות סלארי" המאפיינים חפירות עמוקות בתל אביב.' },
      { title: 'שחיקת אלומיניום', desc: 'תריסים וחלונות שנתקעים עקב הצטברות מלחים ולחות ימית.' },
      { title: 'רטיבות בבנייני לשימור', desc: 'כשלים במעטפת החוץ של מבני באוהאוס ללא שכבת בידוד מודרנית.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '450+' },
      { label: 'ליקויי איטום נפוצים', value: '32%' }
    ],
    image: 'https://images.unsplash.com/photo-1544971587-b842c27f8e14?auto=format&fit=crop&w=1200&q=80'
  },
  'ירושלים': {
    title: 'בדק בית בירושלים | ביקורת מבנים ואיתור ליקויי בנייה',
    desc: 'בדק בית בירושלים: ביקורת הנדסית מותאמת לחיפויי אבן ירושלמית ואקלים הררי. אבחון ליקויי בנייה, בעיות בידוד תרמי ואיטום ע"י מהנדס מומחה מאריקס ביקורת מבנים.',
    soilType: 'סלע גירני וקרקע הררית (יציבה מאוד אך מאתגרת ניקוז ובידוד)',
    buildingStyle: 'חיפוי אבן קשיח (תקן 2378), בנייה מדורגת במדרון',
    article: `כשניגשים ל**בדק בית בירושלים**, האתגר המרכזי הוא הבידוד התרמי (תקן 1045). האקלים הירושלמי מחייב שימוש בלוחות בידוד עבים (קלקר או צמר סלעים) מאחורי האבן הירושלמית כדי למנוע "גשרי קור" הגורמים לעובש שחור בפינות החדרים. בנוסף, אנו בודקים את העיגון המכני של האבנים למניעת נשירה – ליקוי בטיחותי חמור הנפוץ בבנייה חדשה. בבנייה המדורגת (כמו ברמות או הר חומה), אנו בודקים את איטום המרפסות שיושבות מעל חללי מגורים.

המומחים שלנו באריקס ביקורת מבנים מספקים דוחות הנדסיים מפורטים הכוללים צילומים תרמיים ואומדן עלויות לתיקון הליקויים. אנו מלווים את לקוחותינו בירושלים מול הקבלנים כדי להבטיח שכל ליקויי בנייה יתוקנו לשביעות רצונם המלאה ובהתאם לתקנים הישראליים.`,
    points: ['בדיקת עיגון אבן ירושלמית לפי תקן 2378', 'אבחון גשרי קור ועיבוי (קונדנסציה)', 'בדיקת איטום בבנייה מדורגת והררית', 'ביקורת מערכות חימום תת-רצפתי והסקה'],
    commonDefects: [
      { title: 'עובש כרוני בחדרים צפוניים', desc: 'חדירת קור דרך קירות החוץ עקב בידוד תרמי לקוי.' },
      { title: 'נשירת אריחי חיפוי', desc: 'כשלים בעיגון מכני של האבן הירושלמית לקירות השלד.' },
      { title: 'חדירת מים מקירות תמך', desc: 'איטום שלילי לקוי בקירות שפונים לכיוון ההר.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '310+' },
      { label: 'בעיות בידוד תרמי', value: '28%' }
    ],
    image: 'https://images.unsplash.com/photo-1542668595-df665422894f?auto=format&fit=crop&w=1200&q=80'
  },
  'רעננה': {
    title: 'בדק בית ברעננה | איתור ליקויי בנייה ע"י מהנדס מומחה',
    desc: 'זקוקים לבדק בית ברעננה? אנו מבצעים ביקורת מבנים יסודית לדירות חדשות, פרויקטים של תמ"א 38 ובתים פרטיים ברעננה. אבחון הנדסי מקצועי עם ציוד טכנולוגי מתקדם.',
    soilType: 'אדמת חמרה וחול (ניקוז טוב אך דורש הידוק מצעים למניעת שקיעות ריצוף)',
    buildingStyle: 'התחדשות עירונית (תמ"א 38) ובנייה רוויה (נווה זמר)',
    article: `ביצוע **בדק בית ברעננה** מחייב היכרות עם תנופת ההתחדשות העירונית בעיר. בפרויקטים של חיזוק מבנים (תמ"א 38), אנו בודקים בקפידה את החיבור שבין הבנייה הישנה לתוספות החדשות. בשכונות החדשות כמו נווה זמר, הדגש בבדיקה הוא על איכות עבודות הגמר, בידוד אקוסטי בין דירות ומערכות הניקוז במרפסות השמש. אנו מוודאים שהקבלן עמד בכל תקני הבנייה הישראליים למניעת עוגמת נפש עתידית.`,
    points: ['בדיקת חיבורי תוספות בנייה בתמ"א 38', 'אבחון אקוסטיקה ומעברי רעש בבנייה רוויה', 'ביקורת מערכות חשמל ותקשורת חכמות', 'בדיקת מישוריות ושיפועי ריצוף במרפסות'],
    commonDefects: [
      { title: 'סדקים בחיבורי הרחבה', desc: 'תנודות בין השלד הישן לחדש בפרויקטים של תמ"א 38.' },
      { title: 'חדירות מים מחלונות', desc: 'ביצוע לקוי של איטום (ספי חלון) בבנייה מהירה.' },
      { title: 'ליקויים אקוסטיים', desc: 'בידוד לא תקין של צנרת דלוחין העוברת בתקרות.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '380+' },
      { label: 'ליקויי גמר נפוצים', value: '15%' }
    ],
    image: 'https://images.unsplash.com/photo-1590608297077-017e8d53866c?auto=format&fit=crop&w=1200&q=80'
  },
  'הרצליה': {
    title: 'בדק בית בהרצליה | ביקורת מבנים הנדסית וליקויי בנייה',
    desc: 'בדק בית בהרצליה: אבחון מקצועי לדירות יוקרה, מגדלים וצמודי קרקע. מומחים באיתור ליקויי בנייה עקב סביבה ימית ורטיבות כלואה.',
    soilType: 'כורכר (פיתוח) וחמרה (מרכז) - סביבה בעלת מליחות גבוהה',
    buildingStyle: 'מגדלי יוקרה, מבני מגורים מודרניים, וילות פאר',
    article: `שירותי **בדק בית בהרצליה** מתחלקים לשני תחומים עיקריים: מגדלי המגורים במרכז העיר והווילות בהרצליה פיתוח. במבנים הקרובים לקו החוף, מלחים ולחות הם האויב המרכזי. אנו בודקים עמידות של מערכות האלומיניום והזכוכית מול רוחות הים ומבצעים בדיקות איטום מחמירות במרתפים. בהרצליה פיתוח, הבדיקה מתמקדת במערכות מורכבות של בריכות שחייה, מערכות מיזוג וגילוי אש.`,
    points: ['אבחון נזקי מליחות וקורוזיה', 'בדיקת מערכת גמר יוקרה', 'ביקורת איטום מרתפים', 'בדיקת מערכות ניקוז ופיתוח חוץ'],
    commonDefects: [
      { title: 'קורוזיה באלומיניום', desc: 'שחיקה מהירה של מסילות חלון עקב רסס ימי.' },
      { title: 'כשלי איטום במרתפים', desc: 'חדירת מי תהום גבוהים המאפיינים את האזור.' },
      { title: 'ליקויים במערכות חכמות', desc: 'חיווט ותשתיות תקשורת שלא בוצעו לפי דרישות התכנון.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '290+' },
      { label: 'בעיות איטום בסביבה ימית', value: '22%' }
    ],
    image: 'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?auto=format&fit=crop&w=1200&q=80'
  },
  'הוד השרון': {
    title: 'בדק בית בהוד השרון - ביקורת מבנים וליקויי בנייה',
    desc: 'ביצוע בדק בית מקצועי בהוד השרון לדירות חדשות ובנייה רוויה. איתור ליקויי בנייה סמויים, רטיבות ובעיות שלד ע"י מהנדס מומחה.',
    soilType: 'אדמה כבדה/חרסיתית (דורשת התייחסות ליסודות וניקוז פיתוח)',
    buildingStyle: 'מגדלי מגורים חדשים ובתים פרטיים רחבי ידיים',
    article: `ביצוע **בדק בית בהוד השרון** מתמקד בעיקר במגדלי המגורים החדשים. האדמה באזור ידועה כאדמה "כבדה" המחייבת יסודות עמוקים ושיפועי ניקוז מדויקים. אנו בודקים בקפידה את איטום הקירות החיצוניים ואת עמידות השלד מול תזוזות קרקע קלות. בבדיקת דירה חדשה, אנו שמים דגש על בדיקת האינסטלציה ואימות גבהי נקודות חשמל.`,
    points: ['בדיקת יציבות ושלד', 'אבחון איטום וניקוז במרפסות', 'ביקורת מערכות אינסטלציה', 'בדיקת איכות הטיח והצבע'],
    commonDefects: [
      { title: 'שקיעת ריצוף חוץ', desc: 'הצטברות מים תחת הממצעים עקב ניקוז לקוי.' },
      { title: 'ליקויי טיח וגמר', desc: 'סדקים נימיים עקב ייבוש מהיר.' },
      { title: 'בעיות לחץ מים', desc: 'אי ויסות לחצים בקומות העליונות.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '265+' },
      { label: 'ליקויי אינסטלציה', value: '12%' }
    ],
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80'
  },
  'רמת השרון': {
    title: 'בדק בית ברמת השרון | ביקורת מבנים הנדסית יסודית',
    desc: 'בדק בית ברמת השרון: מומחים בביקורת מבנים לבתים פרטיים ודירות בסטנדרט פרימיום. אבחון ליקויי בנייה, איטום ושלד ע"י מהנדס מומחה.',
    soilType: 'חמרה אדומה (שרון) - אדמה יציבה יחסית',
    buildingStyle: 'וילות ותיקות ופרויקטים יוקרתיים של פינוי בינוי',
    article: `שירותי **בדק בית ברמת השרון** נדרשים לרוב בבתים פרטיים איכותיים. האתגר הוא השילוב בין תשתיות ותיקות לבין דרישות גמר גבוהות. אנו בודקים את יציבות המבנים לפני שיפוץ, ובבנייה החדשה – אנו מוודאים שהגמר בוצע ברמה המצופה. דגש מיוחד על איטום גגות ובדיקת מרתפים מאובזרים.`,
    points: ['בדיקת שלד למבנים ותיקים', 'אבחון איכות גמר פרימיום', 'ביקורת תשתיות ניקוז ותיעול', 'בדיקת בידוד תרמי ואקוסטי'],
    commonDefects: [
      { title: 'רטיבות בקומות מרתף', desc: 'כשל באיטום קורות קשר בבתים פרטיים.' },
      { title: 'סדקי מאמץ בתוספות בנייה', desc: 'ביצוע לקוי של תפרי התפשטות.' },
      { title: 'בעיות בניקוז הגג', desc: 'סתימות במרזבים פנימיים.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '220+' },
      { label: 'שביעות רצון (CSAT)', value: '99%' }
    ],
    image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80'
  },
  'שוהם': {
    title: 'בדק בית בשוהם - ביקורת מבנים וליקויי בנייה',
    desc: 'בדק בית בשוהם: ביקורת מבנים הנדסית יסודית לווילות ודירות. איתור ליקויי בנייה, סדקים ובעיות שלד ע"י מהנדס מומחה.',
    soilType: 'חרסית שמנה/תופחת (סיכון גבוה לסדקים מבניים)',
    buildingStyle: 'וילות, קוטג׳ים בבנייה עצמית ובנייה רוויה נמוכה',
    article: `שירותי **בדק בית בשוהם** מתמקדים לרוב בבעיות שלד ופיתוח עקב הקרקע החרסיתית. אנו בודקים את הניתוק בין הרצפה לקרקע ואת שיפועי הניקוז בחצרות. מים שמצטברים ליד יסודות הבית בשוהם הם מתכון לכשלים הנדסיים.`,
    points: ['אבחון סדקי מאמץ בשלד', 'בדיקת ניתוק רצפה מהקרקע', 'בדיקת שיפועי פיתוח וניקוז', 'ביקורת גגות רעפים'],
    commonDefects: [
      { title: 'סדקים בחיבורי קיר-תקרה', desc: 'תנודות של השלד עקב שינויי נפח בקרקע.' },
      { title: 'שקיעת ריצוף חוץ', desc: 'השפעת הקרקע התופחת על משטחי החוץ.' },
      { title: 'רטיבות במרתפים', desc: 'איטום לקוי של קורות קשר.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '240+' },
      { label: 'ליקויים מבניים', value: '18%' }
    ],
    image: 'https://res.cloudinary.com/dbzklnlcx/image/upload/v1770017647/%D7%91%D7%99%D7%AA_%D7%A4%D7%A8%D7%98%D7%99_%D7%91%D7%A9%D7%95%D7%94%D7%9D_yxddu8.jpg'
  },
  'נס ציונה': {
    title: 'בדק בית בנס ציונה - ביקורת מבנים וליקויי בנייה',
    desc: 'בדק בית בנס ציונה: ביקורת הנדסית לדירות חדשות ובתים פרטיים. איתור ליקויי בנייה, בעיות איטום ורטיבות ע"י מהנדס מומחה.',
    soilType: 'אדמת נזז (אטומה למים המייצרת בעיות ניקוז קשות)',
    buildingStyle: 'בנייה רוויה מודרנית וצמודי קרקע',
    article: `שירותי **בדק בית בנס ציונה** מתמודדים עם אתגר אדמת ה"נזז" המונעת חלחול מים טוב. הדבר מוביל להצטברות מים תת-קרקעיים וחדירת רטיבות קפילארית. בשכונות החדשות כמו וואלי, אנו בודקים את איכות הגימור ומישוריות הריצוף.`,
    points: ['אבחון רטיבות קפילארית', 'בדיקת מערכות ניקוז תת-קרקעיות', 'ביקורת איכות ריצוף', 'בדיקת ממ"דים'],
    commonDefects: [
      { title: 'רטיבות בבסיס קירות', desc: 'חדירת מים מהיסודות.' },
      { title: 'ליקויי ניקוז במרפסות', desc: 'שיפועים לא תקינים.' },
      { title: 'כשלי איטום במרתפים', desc: 'חדירת מים בחיבורי רצפה-קיר.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '210+' },
      { label: 'בעיות ניקוז ורטיבות', value: '24%' }
    ],
    image: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=1200&q=80'
  },
  'תל מונד': {
    title: 'בדק בית בתל מונד - ביקורת מבנים וליקויי בנייה',
    desc: 'בדק בית בתל מונד: ביקורת הנדסית לווילות יוקרה ובתים צמודי קרקע. איתור ליקויי בנייה, בעיות איטום וניקוז חצר.',
    soilType: 'חמרה אדומה (יציבה אך דורשת ניקוז איכותי)',
    buildingStyle: 'בנייה עצמית, וילות בסטנדרט גבוה',
    article: `בביצוע **בדק בית בתל מונד**, אנו מתמקדים בנכסים בבנייה עצמית. הקרקע יציבה אך מחייבת מערכת ניקוז חצר מעולה. אנו שמים דגש על בדיקת ה"פיתוח" – שיפועי השבילים והחצרות – כדי לוודא שמי הגשמים לא חודרים ליסודות המבנה.`,
    points: ['בדיקת פיתוח וניקוז חצרות', 'אבחון איטום מרתפים', 'ביקורת גגות רעפים', 'בדיקת גימורי נגרות וריצוף'],
    commonDefects: [
      { title: 'חדירת מים דרך חלונות אנגליים', desc: 'ניקוז לקוי בפתחי המרתף.' },
      { title: 'כשלי איטום במרפסות', desc: 'אי ביצוע בדיקת הצפה כנדרש.' },
      { title: 'סדקים בשליכט חיצוני', desc: 'יישום לא תקין של שכבות היסוד.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '150+' },
      { label: 'דיוק בביצוע גמרים', value: '25%' }
    ],
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'
  },
  'אבן יהודה': {
    title: 'בדק בית באבן יהודה - ביקורת מבנים וליקויי בנייה',
    desc: 'בדק בית באבן יהודה: ביקורת מבנים הנדסית לצמודי קרקע ובנייה עצמית. אבחון ליקויי שלד, איטום וגמרים.',
    soilType: 'חמרה חולית (דורשת ביסוס עמוק)',
    buildingStyle: 'שילוב של בנייה ותיקה (מושבה) ומודרנית',
    article: `ביצוע **בדק בית באבן יהודה** מצריך הבנה של המעבר ממושבה ותיקה לבנייה מודרנית ירוקה. בבתים הישנים אנו בוחנים את תקינות הצנרת ויציבות השלד. בבנייה החדשה הדגש הוא על בידוד תרמי ואקוסיטיקה.`,
    points: ['בדיקת יציבות שלד במבנים ותיקים', 'אבחון תשתיות ביוב וניקוז', 'בדיקת בידוד תרמי בקירות חוץ', 'ביקורת איכות הבנייה בהרחבות'],
    commonDefects: [
      { title: 'שקיעת ריצוף חוץ', desc: 'הידוק מצעים לא מספיק בקרקע חולית.' },
      { title: 'קורוזיה בצנרת ישנה', desc: 'צינורות גלוונים בנכסים ותיקים.' },
      { title: 'ליקויי איטום בגגות רעפים', desc: 'רעפים שבורים הגורמים לרטיבות.' }
    ],
    localStats: [
      { label: 'בדיקות שבוצעו בעיר', value: '130+' },
      { label: 'בעיות תשתיות ותיקות', value: '30%' }
    ],
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80'
  }
};

const LocationPage: React.FC<LocationPageProps> = ({ city }) => {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [city]);

  // Ensure we get the right data, fallback to generic if not found
  const data = cityContent[city] || {
    title: `בדק בית ב${city} לדירה חדשה מקבלן או יד שנייה | אריקס ביקורת מבנים`,
    desc: `זקוקים לבדק בית ב${city}? אריקס ביקורת מבנים מספקת ביקורת מבנים מקצועית ע"י מהנדס מומחה, איתור נזילות במצלמה תרמית ודוח הנדסי מחייב ב${city} והסביבה.`,
    soilType: 'מותאם למאפייני הקרקע הייחודיים של האזור',
    buildingStyle: 'בנייה רוויה מודרנית, התחדשות עירונית ובתים פרטיים',
    article: `ביצוע **בדק בית ב${city}** הוא הצעד החכם ביותר לפני רכישת נכס או קבלת מפתח מקבלן. ב${city}, כמו בערים רבות בישראל, קיימים אתגרי בנייה ייחודיים החל מאיכות האיטום ועד לדיוק בביצוע השלד. מהנדס מומחה מטעמנו יבצע בדיקה יסודית הכוללת איתור ליקויי בנייה סמויים ורטיבות בטכנולוגיה תרמית מתקדמת.

אנו מספקים **דוח בדק בית ב${city}** הכולל אומדן עלויות לתיקון וקביל בבית המשפט במידת הצורך. אל תהמר על ההשקעה הגדולה בחייך – וודא שהבית ב${city} אכן תקין ובטיחותי למגורים.`,
    points: [`איתור רטיבות במצלמה תרמית ב${city}`, `אבחון סדקים וליקויי שלד הנדסיים`, `בדיקת אינסטלציה וחשמל לפי התקן`, `ביקורת דירה חדשה מול מפרט המכר`],
    commonDefects: [
      { title: 'ליקויי איטום ורטיבות', desc: 'כשלים בשיפועי מרפסות וחדירת מים מחלונות.' },
      { title: 'ביצוע לקוי של גמרים', desc: 'סטיות בריצוף, חוסר מישוריות בקירות וליקויי צבע.' },
      { title: 'ליקויי בטיחות ושלד', desc: 'סדקי מאמץ ואי התאמה לתקנות הבנייה והממ"ד.' }
    ],
    localStats: [
      { label: `בדיקות הנדסיות ב${city}`, value: '150+' },
      { label: 'דיוק באיתור ליקויים', value: '100%' }
    ],
    image: 'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?auto=format&fit=crop&w=1200&q=80'
  };

  return (
    <div className="bg-white text-slate-600 min-h-screen">
      <SchemaTags type="LocalBusiness" data={{ name: `אריקס ביקורת מבנים - ${data.title}`, description: data.desc }} />

      <section className="relative pt-52 pb-20 overflow-hidden bg-slate-50">
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-5xl mx-auto text-right">
            <Breadcrumbs items={[{ label: 'אזורי שירות' }, { label: data.title }]} />
            <div className="flex flex-col lg:flex-row gap-12 items-start mt-8">
              <div className="lg:w-2/3">
                <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-slate-900 mb-6 leading-none">{data.title}</h1>
                <p className="text-2xl text-blue-600 font-bold mb-8 italic">{data.desc}</p>
                <div className="flex flex-wrap gap-4">
                   <div className="bg-blue-50 border border-blue-100 px-6 py-3 rounded-2xl">
                      <span className="text-xs text-slate-400 block uppercase font-black">מאפייני קרקע</span>
                      <span className="text-slate-900 font-bold">{data.soilType}</span>
                   </div>
                   <div className="bg-blue-50 border border-blue-100 px-6 py-3 rounded-2xl">
                      <span className="text-xs text-slate-400 block uppercase font-black">טיפולוגיית בנייה</span>
                      <span className="text-slate-900 font-bold">{data.buildingStyle}</span>
                   </div>
                </div>
              </div>
              <div className="lg:w-1/3 w-full grid grid-cols-2 gap-4">
                 {data.localStats.map((stat, i) => (
                   <div key={i} className="bg-white border border-slate-100 p-6 rounded-[2rem] text-center shadow-sm">
                      <div className="text-4xl font-black text-blue-600 mb-2">{stat.value}</div>
                      <div className="text-xs text-slate-400 font-bold uppercase tracking-widest">{stat.label}</div>
                   </div>
                 ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 text-right">
              <div className="lg:col-span-2 space-y-10">
                <div className="bg-slate-50 p-8 md:p-12 rounded-[3rem] border border-slate-100">
                  <h2 className="text-3xl font-black text-slate-900 mb-8 italic">בדק בית באזור {city}</h2>
                  <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed text-lg space-y-6">
                    {data.article.split('\n\n').map((paragraph, i) => (
                      <p key={i} dangerouslySetInnerHTML={{ __html: paragraph.replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-900">$1</strong>') }} />
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.points.map((p) => (
                    <div key={p} className="flex items-center justify-end gap-4 bg-white p-6 rounded-2xl border border-slate-100 hover:border-blue-500/50 transition-all shadow-sm group">
                      <span className="font-bold text-slate-900 leading-tight">{p}</span>
                      <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center font-black group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"/></svg>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <aside className="lg:col-span-1">
                <div className="sticky top-32 bg-blue-600 text-white p-10 rounded-[3rem] shadow-xl">
                   <h3 className="text-2xl font-black mb-8 italic">ליקויים נפוצים ב{city}</h3>
                   <div className="space-y-8">
                     {data.commonDefects.map((defect, i) => (
                       <div key={i} className="space-y-2 border-b border-white/10 pb-6 last:border-0">
                         <h4 className="font-black text-lg flex items-center justify-end gap-2 text-white">
                           {defect.title}
                           <span className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center text-[10px]">{i+1}</span>
                         </h4>
                         <p className="text-blue-100 text-sm">{defect.desc}</p>
                       </div>
                     ))}
                   </div>
                   <div className="mt-10">
                     <a href="#contact" className="block w-full bg-white text-blue-600 text-center font-black py-5 rounded-2xl shadow-lg hover:bg-slate-50 transition-all">הזמן בדיקת מהנדס</a>
                   </div>
                </div>
              </aside>
            </div>
          </div>
        </div>
      </section>

      <CommonSections />
    </div>
  );
};

export default LocationPage;
